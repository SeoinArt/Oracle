package day04;

import java.sql.CallableStatement;
import java.sql.Connection;

import javax.swing.JOptionPane;

import common.util.DBUtil;
/*
-------------------------------
 create or replace procedure memo_edit
(pno in number, pname in varchar2, pmsg in varchar2)
is
begin
    update memo set name=pname, msg=pmsg
    where no=pno;
    commit;
end;
/
-------------------------------
 * */
public class MemoUpdate {
	
	public static void main(String[] args) throws Exception {
		String noStr=JOptionPane.showInputDialog("수정할 글번호를 입력하세요");
		String name=JOptionPane.showInputDialog("수정할 작성자명을 입력하세요");
		String msg=JOptionPane.showInputDialog("수정할 메모 내용을 입력하세요");
		if(noStr==null||name==null|| msg==null) return;
		
		Connection con=DBUtil.getCon();
		String sql="{call memo_edit(?,?,?)}";
		
		CallableStatement cs=con.prepareCall(sql);
		//in parameter값 setting
		cs.setInt(1, Integer.parseInt(noStr));
		cs.setString(2, name);
		cs.setString(3, msg);
		
		//실행
		cs.execute();
		System.out.println("메모 글 수정 성공!!");
		
		cs.close();
		con.close();
	}

}
